package com.example.dotsbt

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import java.io.IOException
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.Executors
import kotlin.concurrent.thread

/** اتصال بلوتوث کلاسیک (RFCOMM). پیام‌ها متن‌اند و هرکدام یک خط. */
@SuppressLint("MissingPermission")
class BtConnection(
    private val onMessage: (String) -> Unit,
    private val onState: (String) -> Unit   // "connected" | "disconnected" | "error"
) {
    private val uuid = UUID.fromString("8f3b1c52-6a1e-4e0b-9d57-2b7d5a1c9e10")
    private var out: OutputStream? = null
    private var serverSocket: android.bluetooth.BluetoothServerSocket? = null
    private val sender = Executors.newSingleThreadExecutor()

    fun host(adapter: BluetoothAdapter) = thread {
        try {
            val s = adapter.listenUsingRfcommWithServiceRecord("DotsBT", uuid)
            serverSocket = s
            val c = s.accept()      // منتظر می‌ماند تا مهمان وصل شود
            s.close()
            run(c)
        } catch (e: IOException) { onState("error") }
    }

    fun join(device: BluetoothDevice, adapter: BluetoothAdapter) = thread {
        try {
            adapter.cancelDiscovery()
            val c = device.createRfcommSocketToServiceRecord(uuid)
            c.connect()
            run(c)
        } catch (e: IOException) { onState("error") }
    }

    private fun run(c: BluetoothSocket) {
        out = c.outputStream
        onState("connected")
        try {
            val reader = c.inputStream.bufferedReader()
            while (true) onMessage(reader.readLine() ?: break)
        } catch (_: IOException) { }
        onState("disconnected")
    }

    fun send(msg: String) {
        sender.execute {
            try { out?.write((msg + "\n").toByteArray()); out?.flush() } catch (_: IOException) { }
        }
    }

    fun close() { try { serverSocket?.close() } catch (_: IOException) { }; try { out?.close() } catch (_: IOException) { } }
}
