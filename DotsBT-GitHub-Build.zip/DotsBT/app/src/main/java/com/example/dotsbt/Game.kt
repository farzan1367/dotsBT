package com.example.dotsbt

/** منطق بازی. h: خط‌های افقی، v: خط‌های عمودی. مقدار -1 یعنی خالی، وگرنه شماره بازیکن (0 یا 1) */
class Game(val rows: Int = 5, val cols: Int = 5) {
    val h = Array(rows + 1) { IntArray(cols) { -1 } }
    val v = Array(rows) { IntArray(cols + 1) { -1 } }
    val box = Array(rows) { IntArray(cols) { -1 } }
    val score = IntArray(2)
    var turn = 0

    val finished get() = score[0] + score[1] == rows * cols

    fun isFree(horiz: Boolean, r: Int, c: Int) =
        (if (horiz) h[r][c] else v[r][c]) == -1

    /** یک حرکت انجام می‌دهد. اگر معتبر نبود false برمی‌گرداند. */
    fun play(horiz: Boolean, r: Int, c: Int): Boolean {
        if (finished || !isFree(horiz, r, c)) return false
        val p = turn
        if (horiz) h[r][c] = p else v[r][c] = p
        var got = 0
        fun check(br: Int, bc: Int) {
            if (br in 0 until rows && bc in 0 until cols && box[br][bc] == -1 &&
                h[br][bc] != -1 && h[br + 1][bc] != -1 &&
                v[br][bc] != -1 && v[br][bc + 1] != -1
            ) { box[br][bc] = p; score[p]++; got++ }
        }
        if (horiz) { check(r - 1, c); check(r, c) } else { check(r, c - 1); check(r, c) }
        if (got == 0) turn = 1 - turn   // اگر خانه نگرفت نوبت عوض می‌شود
        return true
    }
}
