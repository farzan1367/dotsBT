package com.example.dotsbt

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.roundToInt

class BoardView(ctx: Context, private val game: Game) : View(ctx) {
    var onLineTap: ((horiz: Boolean, r: Int, c: Int) -> Unit)? = null
    private val colors = intArrayOf(Color.rgb(33, 150, 243), Color.rgb(244, 67, 54))
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var cell = 0f; private var ox = 0f; private var oy = 0f

    private fun layout() {
        val m = 50f
        cell = min((width - 2 * m) / game.cols, (height - 2 * m) / game.rows)
        ox = (width - cell * game.cols) / 2; oy = (height - cell * game.rows) / 2
    }

    override fun onDraw(c: Canvas) {
        layout()
        // خانه‌های گرفته‌شده
        for (r in 0 until game.rows) for (q in 0 until game.cols) {
            val o = game.box[r][q]; if (o == -1) continue
            p.style = Paint.Style.FILL; p.color = colors[o]; p.alpha = 70
            c.drawRect(ox + q * cell + 6, oy + r * cell + 6, ox + (q + 1) * cell - 6, oy + (r + 1) * cell - 6, p)
            p.alpha = 255; p.textSize = cell * 0.4f; p.textAlign = Paint.Align.CENTER
            c.drawText(if (o == 0) "A" else "B", ox + (q + 0.5f) * cell, oy + (r + 0.5f) * cell + cell * 0.14f, p)
        }
        // خط‌ها
        p.strokeWidth = 12f; p.strokeCap = Paint.Cap.ROUND
        for (r in 0..game.rows) for (q in 0 until game.cols) {
            p.color = if (game.h[r][q] == -1) Color.LTGRAY else colors[game.h[r][q]]
            c.drawLine(ox + q * cell, oy + r * cell, ox + (q + 1) * cell, oy + r * cell, p)
        }
        for (r in 0 until game.rows) for (q in 0..game.cols) {
            p.color = if (game.v[r][q] == -1) Color.LTGRAY else colors[game.v[r][q]]
            c.drawLine(ox + q * cell, oy + r * cell, ox + q * cell, oy + (r + 1) * cell, p)
        }
        // نقطه‌ها
        p.color = Color.DKGRAY; p.style = Paint.Style.FILL
        for (r in 0..game.rows) for (q in 0..game.cols) c.drawCircle(ox + q * cell, oy + r * cell, 14f, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_UP) return true
        val x = e.x; val y = e.y
        var best = cell * 0.35f; var res: Triple<Boolean, Int, Int>? = null
        // افقی
        val hr = ((y - oy) / cell).roundToInt(); val hc = floor((x - ox) / cell).toInt()
        if (hr in 0..game.rows && hc in 0 until game.cols) {
            val d = abs(y - (oy + hr * cell)); if (d < best) { best = d; res = Triple(true, hr, hc) }
        }
        // عمودی
        val vr = floor((y - oy) / cell).toInt(); val vc = ((x - ox) / cell).roundToInt()
        if (vr in 0 until game.rows && vc in 0..game.cols) {
            val d = abs(x - (ox + vc * cell)); if (d < best) { res = Triple(false, vr, vc) }
        }
        res?.let { onLineTap?.invoke(it.first, it.second, it.third) }
        return true
    }
}
