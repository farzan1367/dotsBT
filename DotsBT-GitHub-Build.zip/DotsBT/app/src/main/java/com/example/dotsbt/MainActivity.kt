package com.example.dotsbt

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

@SuppressLint("MissingPermission")
class MainActivity : Activity() {
    private lateinit var adapter: BluetoothAdapter
    private lateinit var status: TextView
    private lateinit var menu: LinearLayout
    private lateinit var root: LinearLayout
    private var board: BoardView? = null
    private var game = Game()
    private var bt: BtConnection? = null
    private var myIdx = 0
    private var connected = false
    private var pendingAction: (() -> Unit)? = null

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 48, 24, 24) }
        status = TextView(this).apply { textSize = 20f; gravity = Gravity.CENTER; text = "بازی نقطه و خط (بلوتوثی)" }
        menu = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        menu.addView(Button(this).apply { text = "میزبان بازی شو"; setOnClickListener { withPermission { startHost() } } })
        menu.addView(Button(this).apply { text = "اتصال به دوستم"; setOnClickListener { withPermission { pickDevice() } } })
        root.addView(status); root.addView(menu)
        setContentView(root)
    }

    // ---- مجوزها ----
    private fun withPermission(action: () -> Unit) {
        if (!adapter.isEnabled) { toast("اول بلوتوث را روشن کنید"); return }
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            pendingAction = action
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1)
        } else action()
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) pendingAction?.invoke()
        else toast("بدون مجوز بلوتوث بازی کار نمی‌کند")
        pendingAction = null
    }

    // ---- اتصال ----
    private fun newConnection() {
        bt?.close()
        bt = BtConnection(
            onMessage = { msg -> runOnUiThread { onMessage(msg) } },
            onState = { st -> runOnUiThread { onState(st) } })
    }

    private fun startHost() {
        myIdx = 0; newConnection()
        status.text = "منتظر اتصال دوست شما... (دو گوشی باید قبلاً در تنظیمات بلوتوث جفت شده باشند)"
        bt!!.host(adapter)
    }

    private fun pickDevice() {
        val devices = adapter.bondedDevices.toList()
        if (devices.isEmpty()) { toast("اول در تنظیمات بلوتوث دو گوشی را جفت کنید"); return }
        AlertDialog.Builder(this).setTitle("میزبان را انتخاب کنید")
            .setItems(devices.map { it.name ?: it.address }.toTypedArray()) { _, i ->
                myIdx = 1; newConnection()
                status.text = "در حال اتصال..."
                bt!!.join(devices[i], adapter)
            }.show()
    }

    private fun onState(st: String) {
        when (st) {
            "connected" -> { connected = true; startGame() }
            "disconnected" -> { connected = false; status.text = "ارتباط قطع شد"; }
            "error" -> { connected = false; status.text = "اتصال برقرار نشد. دوباره تلاش کنید." }
        }
    }

    // ---- بازی ----
    private fun startGame() {
        game = Game()
        board?.let { root.removeView(it) }
        menu.removeAllViews()
        board = BoardView(this, game).also {
            it.layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
            it.onLineTap = { horiz, r, c -> onLocalTap(horiz, r, c) }
            root.addView(it)
        }
        refreshStatus()
    }

    private fun onLocalTap(horiz: Boolean, r: Int, c: Int) {
        if (!connected || game.turn != myIdx || game.finished) return
        if (game.play(horiz, r, c)) {
            bt?.send("L,${if (horiz) 1 else 0},$r,$c")
            board?.invalidate(); refreshStatus()
        }
    }

    private fun onMessage(msg: String) {
        val t = msg.split(",")
        if (t.size == 4 && t[0] == "L" && game.turn != myIdx) {
            game.play(t[1] == "1", t[2].toInt(), t[3].toInt())
            board?.invalidate(); refreshStatus()
        }
    }

    private fun refreshStatus() {
        val me = if (myIdx == 0) "A" else "B"
        val score = "A: ${game.score[0]}   B: ${game.score[1]}"
        status.text = when {
            game.finished -> {
                val w = when { game.score[0] > game.score[1] -> 0; game.score[1] > game.score[0] -> 1; else -> -1 }
                "$score\n" + if (w == -1) "مساوی شد!" else if (w == myIdx) "شما برنده شدید! 🎉" else "حریف برنده شد"
            }
            game.turn == myIdx -> "شما بازیکن $me هستید — نوبت شماست\n$score"
            else -> "شما بازیکن $me هستید — نوبت حریف\n$score"
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    override fun onDestroy() { bt?.close(); super.onDestroy() }
}
